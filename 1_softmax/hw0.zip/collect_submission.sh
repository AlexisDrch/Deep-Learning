rm -f hw0.zip
zip -r hw0.zip . -x "*.git*" "*f17cs7643/data*" "*.ipynb_checkpoints*" "*README.md" "*collectSubmission.sh" "*requirements.txt"
