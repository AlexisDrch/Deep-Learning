wget http://cs231n.stanford.edu/imagenet_val_25.npz
