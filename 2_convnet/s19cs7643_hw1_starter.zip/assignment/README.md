http://ripl.cc.gatech.edu/classes/AY2019/cs7643_spring/hw1-q6/
